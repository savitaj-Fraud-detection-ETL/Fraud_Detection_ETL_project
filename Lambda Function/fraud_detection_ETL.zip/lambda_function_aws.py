import json
import boto3
import psycopg2
import os
import logging
import csv

# Initialize Logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize S3 client
s3_client = boto3.client("s3")

# Database Credentials (From Lambda Environment Variables)
DB_HOST = os.environ["RDS_HOST"]
DB_NAME = os.environ["RDS_DB"]
DB_USER = os.environ["RDS_USER"]
DB_PASS = os.environ["RDS_PASS"]

def lambda_handler(event, context):
    try:
        logger.info("Lambda execution started")
        
        # Extract bucket and file name from S3 event
        bucket_name = event["Records"][0]["s3"]["bucket"]["name"]
        file_key = event["Records"][0]["s3"]["object"]["key"]
        logger.info(f"Bucket: {bucket_name}, File: {file_key}")

        # Download file from S3
        local_file_path = f"/tmp/{os.path.basename(file_key)}"
        s3_client.download_file(bucket_name, file_key, local_file_path)
        logger.info(f"File downloaded to {local_file_path}")

        # Read CSV using built-in csv module
        transactions = []
        with open(local_file_path, mode="r", newline="") as file:
            reader = csv.DictReader(file)
            for row in reader:
                transactions.append({
                    "step": int(row["step"]),
                    "type": row["type"],
                    "amount": float(row["amount"]),
                    "nameOrig": row["nameOrig"],
                    "oldbalanceOrg": float(row["oldbalanceorg"]),
                    "newbalanceOrig": float(row["newbalanceorig"]),
                    "nameDest": row["nameDest"],
                    "oldbalanceDest": float(row["oldbalancedest"]),
                    "newbalanceDest": float(row["newbalancedest"]),
                    "isFraud": int(row["isFraud"]),
                    "isFlaggedFraud": int(row["isFlaggedFraud"])
                })

        logger.info(f"Rows fetched from CSV: {len(transactions)}")

        # Filter Valid Transactions
        valid_transactions = [
            t for t in transactions if (
                round(t["oldbalanceOrg"] - t["newbalanceOrig"], 2) >= t["amount"] or
                round(t["oldbalanceDest"] + t["amount"], 2) >= t["newbalanceDest"]
            )
        ]
        logger.info(f"Valid transactions count: {len(valid_transactions)}")

        # Identify Fraud Transactions
        fraud_transactions = [
            t for t in valid_transactions if t["isFraud"] == 1 or t["isFlaggedFraud"] == 1
        ]
        logger.info(f"Fraud transactions count: {len(fraud_transactions)}")

        if not fraud_transactions:
            logger.info("No fraud transactions found.")
            return {
                "statusCode": 200,
                "body": json.dumps("No fraud transactions found.")
            }

        # Connect to PostgreSQL
        conn = psycopg2.connect(
            host=DB_HOST, dbname=DB_NAME, user=DB_USER, password=DB_PASS
        )
        cur = conn.cursor()
        logger.info("Database connection established")

        # Create Table (If Not Exists)
        create_table_query = """
        CREATE TABLE IF NOT EXISTS fraud_transactions (
            id SERIAL PRIMARY KEY,
            step INT,
            type VARCHAR(20),
            amount FLOAT,
            nameOrig VARCHAR(50),
            oldbalanceOrg FLOAT,
            newbalanceOrig FLOAT,
            nameDest VARCHAR(50),
            oldbalanceDest FLOAT,
            newbalanceDest FLOAT,
            isFraud INT,
            isFlaggedFraud INT
        );
        """
        cur.execute(create_table_query)
        logger.info("Ensured table exists")

        # Batch Insert Data
        insert_query = """
        INSERT INTO fraud_transactions 
        (step, type, amount, nameOrig, oldbalanceOrg, newbalanceOrig, nameDest, oldbalanceDest, newbalanceDest, isFraud, isFlaggedFraud)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
        """
        
        data_to_insert = [(t["step"], t["type"], t["amount"], t["nameOrig"], t["oldbalanceOrg"], 
                          t["newbalanceOrig"], t["nameDest"], t["oldbalanceDest"], 
                          t["newbalanceDest"], t["isFraud"], t["isFlaggedFraud"]) for t in fraud_transactions]

        cur.executemany(insert_query, data_to_insert)

        conn.commit()
        logger.info(f"{len(fraud_transactions)} fraud transactions inserted into RDS")

        cur.close()
        conn.close()
        logger.info("Database connection closed")

        return {
            "statusCode": 200,
            "body": json.dumps(f"{len(fraud_transactions)} fraud transactions processed and stored in RDS!")
        }

    except Exception as e:
        logger.error(f"Error encountered: {str(e)}")
        return {"statusCode": 500, "body": json.dumps(str(e))}
